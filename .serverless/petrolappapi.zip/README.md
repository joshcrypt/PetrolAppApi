To install the dependencies run the command below
    npm install

    Fixed the error below by adding this at the end of the petroldetails.js file module.exports = router;
    TypeError: Router.use() requires a middleware function but got a Object